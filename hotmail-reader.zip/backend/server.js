import express from "express";
import cors from "cors";
import dotenv from "dotenv";

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

app.get("/api/messages", (req, res) => {
  res.json([
    { id: 1, from: "test1@example.com", subject: "Welcome!", date: "2025-09-27" },
    { id: 2, from: "test2@example.com", subject: "Your invoice", date: "2025-09-26" },
    { id: 3, from: "test3@example.com", subject: "Meeting tomorrow", date: "2025-09-25" }
  ]);
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`✅ Backend running on port ${PORT}`));
