import EmailTable from "./components/EmailTable";

function App() {
  return (
    <div style={{ padding: "20px" }}>
      <h1>📧 Hotmail Reader</h1>
      <EmailTable />
    </div>
  );
}

export default App;
